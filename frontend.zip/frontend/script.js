function show(section) {
  document.querySelectorAll(".main > div").forEach(d => d.classList.add("hidden"));
  document.getElementById(section).classList.remove("hidden");
}

// Upload Resume
async function upload() {
  let file = document.getElementById("file").files[0];
  let formData = new FormData();
  formData.append("file", file);

  await fetch("http://127.0.0.1:5000/upload", {
    method: "POST",
    body: formData
  });

  alert("✅ Resume Uploaded");
}

// Skills
async function getSkills() {
  let box = document.getElementById("skillsList");
  box.innerHTML = "Loading...";

  let res = await fetch("http://127.0.0.1:5000/skills");
  let data = await res.json();

  box.innerHTML =
    data.skills.split(",").map(s => `<div class="card">${s}</div>`).join("");
}

// Jobs
async function getJobs() {
  let role = document.getElementById("role").value;
  let box = document.getElementById("jobList");

  box.innerHTML = "Loading...";

  let res = await fetch(`http://127.0.0.1:5000/jobs?role=${role}`);
  let data = await res.json();

  box.innerHTML =
    data.map(j => `<div class="card">${j.title} - ${j.company_name}</div>`).join("");
}

// Match Jobs
async function matchJobs() {
  let box = document.getElementById("matchList");
  box.innerHTML = "Loading...";

  let res = await fetch("http://127.0.0.1:5000/match");
  let data = await res.json();

  box.innerHTML =
    data.map(j => `<div class="card">${j.title}</div>`).join("");
}

// Recommendation
async function recommend() {
  let box = document.getElementById("recList");
  box.innerHTML = "Loading...";

  let res = await fetch("http://127.0.0.1:5000/recommend");
  let data = await res.json();

  box.innerHTML =
    data.map(j => `<div class="card">${j.title}</div>`).join("");
}

// Skill Gap
async function getGap() {
  let box = document.getElementById("gapList");
  box.innerHTML = "Loading...";

  let res = await fetch("http://127.0.0.1:5000/gap");
  let data = await res.json();

  box.innerHTML =
    data.gap.map(s => `<div class="card">${s}</div>`).join("");
}

// Roadmap
async function getRoadmap() {
  let box = document.getElementById("roadmapList");
  box.innerHTML = "Loading...";

  let res = await fetch("http://127.0.0.1:5000/roadmap");
  let data = await res.json();

  box.innerHTML =
    data.steps.map(s => `<div class="card">${s}</div>`).join("");
}

// Interview
async function getInterview() {
  let box = document.getElementById("interviewList");
  box.innerHTML = "Loading...";

  let res = await fetch("http://127.0.0.1:5000/interview");
  let data = await res.json();

  box.innerHTML =
    data.questions.map(q => `<div class="card">${q}</div>`).join("");
}

// Chatbot
async function ask() {
  let q = document.getElementById("question").value;
  let box = document.getElementById("chatBox");

  let res = await fetch("http://127.0.0.1:5000/chat", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({question: q})
  });

  let data = await res.json();

  box.innerHTML += `<div><b>You:</b> ${q}</div>`;
  box.innerHTML += `<div><b>AI:</b> ${data.answer}</div>`;

  box.scrollTop = box.scrollHeight;
}